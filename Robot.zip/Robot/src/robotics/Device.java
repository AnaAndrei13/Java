package robotics;

public interface Device {
    void on();
    void off();

}
