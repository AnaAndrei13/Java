package robotics;

public interface Mechanism {
    void move();
}
