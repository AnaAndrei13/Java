package robotics;

public interface Computer extends Device {
    void boot();
}
