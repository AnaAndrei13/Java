import robotics.Computer;
import robotics.Mechanism;

public class Robot implements Computer, Mechanism {
    @Override
    public void on(){
        System.out.println("Robot powered on");
    }
    @Override
    public void off(){
        System.out.println("Robot powered off");
    }

    @Override
    public void boot(){
        System.out.println("Robot booted");
    }


    @Override
    public void move(){
        System.out.println("Robot moving");
    }
}
