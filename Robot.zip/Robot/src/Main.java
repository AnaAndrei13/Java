public class Main {
    public static void main(String[] args) {
        Robot robot = new Robot();
        robot.on();
        robot.boot();
        robot.move();
        robot.off();
    }
}
